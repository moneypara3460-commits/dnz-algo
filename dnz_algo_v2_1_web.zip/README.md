# DNZ ALGO V2.1 Web

Streamlit tabanlı canlı market scanner.

## Çalıştırma

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy

GitHub repo köküne `app.py` ve `requirements.txt` koyup Streamlit Community Cloud üzerinden deploy edilebilir.
